import os

files = os.listdir('.')
f = open("tickers.txt","a")

for file in files:
    if str(file)[-4:] == '.zip':
        ticker = file[:-4]
        print(ticker)
        f.write(ticker + "\n")
f.close()
